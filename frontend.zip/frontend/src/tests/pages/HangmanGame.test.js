import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom";
import HangmanGame from "../pages/HangmanGame.jsx";

test("renders HangmanGame with title and game elements", () => {
  render(<HangmanGame />);
  expect(screen.getByText("Hangman")).toBeInTheDocument(); // Prüft Titel
  expect(screen.getByTestId("game-container")).toBeInTheDocument(); // Prüft Spielcontainer
});
