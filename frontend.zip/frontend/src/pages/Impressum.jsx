import React from "react";


export default function Impressum() {

    return (
        <div>
            <h1>Impressum</h1>
            <h2>Fabian Wehrle und Mazlum Raimi</h2>
            <h3>Dieses Projekt wurde im Rahmen einer Projektarbeit erstellt und dient ausschließlich schulischen Zwecken.</h3>
            <p>Adresse: WISS</p>
            <p>Oberer Graben 26</p>
            <p>9000 St. Gallen</p>
        </div>
    )
}